#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	<math.h>
#define		EARTH_RADIUS 6371.0	/* in km */
#define		MU 3.0e11		/* shear modulus in cgs */
#define		DEPTH 15.0		/* seismogenic thickness in km */
#define		MAX_POINTS 8000
#define		MAX_KNOTS	8000

double sunit=1.0e-9;
void read_a_line(FILE *f);
void deal_with_options(int ac, char **av, char* filename, char* filename1);
void usage(void);
int g_flag=0, d_flag=0, e_flag=0;
double sigma=1.0;

int main(int argc, char **argv)
{
	double lat[MAX_KNOTS], lon[MAX_KNOTS], vary[MAX_KNOTS][3][3];
	double ve[MAX_KNOTS], vn[MAX_KNOTS], dm;
	double lat1[MAX_KNOTS], lon1[MAX_KNOTS], vary1[MAX_KNOTS][3][3];
	double ve1[MAX_KNOTS], vn1[MAX_KNOTS];
	double resx, resy, dtemp;
	double su, cof, vx, vy, vxy, sunit=1.0e-9, sum, sumvar=0.0, sum1=0.0;
	FILE *inf, *inf1, *outf, *outf1, *outf2;
	int i, j, k, num, num1, rig=0, g1=0, g2=0;
	char fobserved[25], fmodel[25];
	char fileout[25],fileout1[25],fileout2[25];
	su = EARTH_RADIUS*1.0e6*sunit;
	strcpy(fobserved, "velocity_observed.out");
	strcpy(fmodel, "velocity_model.out");
	strcpy(fileout, "vel_diff.gmt");
	strcpy(fileout1, "vel1.gmt");
	strcpy(fileout2, "vel2.gmt");
	deal_with_options(argc, argv,fobserved, fmodel);
	if( (inf = fopen(fobserved, "r")) == NULL) {
		printf(" file %s not exist\n", fobserved);
		exit(1);
	}
	if( (inf1 = fopen(fmodel, "r")) == NULL) {
		printf(" file %s not exist\n", fmodel);
		exit(1);
	}
	if(sigma < 1.0)
		sigma = sqrt(-2.0*log10(1.0 - sigma));
	outf = fopen(fileout, "w");
	outf1 = fopen(fileout1, "w");
	outf2 = fopen(fileout2, "w");

/*	READ VELOCITY DATA FROM THE FIRST SOLUTION */
	read_a_line(inf);
	i=0;
	while( (k=fscanf(inf, "%d", &j)) == 1) {
		fscanf(inf , "%lf%lf%lf%lf%lf%lf%lf%lf", 
			&lat[i], &lon[i], &ve[i], &vn[i], &dm, &dm, &dm, &dm);
	/*	printf("%5d\n", j); */
		i++;
	}
	num = i;
	printf("Total number of points is %d\n", num);
	read_a_line(inf);
	for(i=0; i<num; i++) {
		read_a_line(inf);
		read_a_line(inf);
		for(j=0; j<3; j++){
			for(k=0; k<3; k++) {
				fscanf(inf, "%lf", &vary[i][j][k]);
				
			}
			/* printf("%7d %g %g %g\n", i, vary[i][j][0],vary[i][j][1],vary[i][j][2]); */
		}
	}
/*	WRITE OUT VELOCITY COMPONENTS FOR PLOTING THE first SOLUTION */
	for(i=0; i<num; i++) {
		if((vary[i][0][0]*vary[i][1][1])>0.1e-14)
			cof = vary[i][0][1]/sqrt(vary[i][0][0]*vary[i][1][1]);
		else
			cof=0.0;
		vx = sqrt(vary[i][0][0]);
		vy = sqrt(vary[i][1][1]);
		if(lon[i] < 0.0)
			lon[i] = lon[i] + 360.0;
		if(d_flag == 0)
		fprintf(outf1, "%10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %8.4f\n",
			lon[i], lat[i], ve[i]*su, vn[i]*su, vx*su, vy*su, cof);
	}
/*	READ VELOCITY DATA FROM THE second SOLUTION */
	read_a_line(inf1);
	i=0;
	while( (k=fscanf(inf1, "%d", &j)) == 1) {
		fscanf(inf1 , "%lf%lf%lf%lf%lf%lf%lf%lf", 
			&lat1[i], &lon1[i], &ve1[i], &vn1[i], &dm, &dm, &dm, &dm);
	/*	printf("%5d\n", j); */
		i++;
	}
	num1 = i;
	printf("Total number of points is %d\n", num);
	if(num1 != num) {
		printf("The two velocity file do not contain the same number of velocities\n");
		exit(0);
	}
	read_a_line(inf1);
	for(i=0; i<num1; i++) {
		read_a_line(inf1);
		read_a_line(inf1);
		for(j=0; j<3; j++){
			for(k=0; k<3; k++) {
				fscanf(inf1, "%lf", &vary1[i][j][k]);
				
			}
			/*printf("%7d %g %g %g\n", i, vary1[i][j][0],vary1[i][j][1],vary1[i][j][2]); */
		}
	}
/*	WRITE OUT VELOCITY COMPONENTS FOR PLOTING THE second SOLUTION and their differences */
	sum = 0.0;
	for(i=0; i<num1; i++) {
	  if((vary1[i][0][0]*vary1[i][1][1])>0.1e-14)
	    cof = vary1[i][0][1]/sqrt(vary1[i][0][0]*vary1[i][1][1]);
	  else
	    cof=0.0;
	  vx = sqrt(vary1[i][0][0]);
	  vy = sqrt(vary1[i][1][1]);
	  if(lon1[i] < 0.0)
	    lon1[i] = lon1[i] + 360.0;
	  if(d_flag == 0)
	    fprintf(outf2, "%10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %8.4f\n",
		    lon1[i], lat1[i], ve1[i]*su, vn1[i]*su, vx*su, vy*su, cof);
	  if(e_flag == 1) {
	    vx = (vary[i][0][0]);
	    vy = (vary[i][1][1]);
	    vxy = (vary[i][0][1]);
	  }
	  else if(e_flag == 2) {
	    vx = (vary1[i][0][0]);
	    vy = (vary1[i][1][1]);
	    vxy = (vary1[i][0][1]);
	  }
	  else {
	    vx = (vary1[i][0][0] + vary[i][0][0]);
	    vy = (vary1[i][1][1] + vary[i][1][1]);
	    vxy = (vary1[i][0][1] + vary[i][0][1]);
	  }
	  if(vx*vy>0.0)
	    cof = vxy/sqrt(vx*vy);
	  else
	    cof=0.0;
	  if(d_flag == 0)
	    fprintf(outf, "%10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %8.4f\n",
		    lon1[i], lat1[i], (ve[i]-ve1[i])*su, (vn[i] - vn1[i])*su, sqrt(vx)*su, sqrt(vy)*su, cof);
	  if(vx>0.0 && vy > 0.0) {
	    resx = (ve[i]-ve1[i])*(ve[i]-ve1[i])/vx;
	    resy = (vn[i] - vn1[i])*(vn[i] - vn1[i])/vy;
	    /* printf("%6d %9.3f %9.3f\n", i, resx, resy); */
	    if(resx>9.0)
	      g2++;
	    if(resy>9.0)
	      g2++;
	    if(resx > 1.0)
	      g1++;
	    if(resy > 1.0)
	      g1++;
	    if(d_flag)
	      if(resy>4.0 || resx > 4.0 ) {
		fprintf(outf, "%10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %8.4f %9.1f\n",
			lon1[i], lat1[i], (ve[i]-ve1[i])*su, (vn[i] - vn1[i])*su, 
			sqrt(vx)*su, sqrt(vy)*su, cof,
			(ve[i]-ve1[i])*(ve[i]-ve1[i])/vx + (vn[i] - vn1[i])*(vn[i] - vn1[i])/vy);
		dtemp = vary1[i][0][0]*vary1[i][1][1];
		dtemp = dtemp>0.0?dtemp:1.0;
		fprintf(outf2, "%10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %8.4f\n",
			lon1[i], lat1[i], (ve1[i])*su, (vn1[i])*su, sqrt(vary1[i][0][0]+1.0e-7)*su, 
			sqrt(vary1[i][1][1] + 1.0e-7)*su, 
			vary1[i][0][1]/sqrt(dtemp));
		fprintf(outf1, "%10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %8.4f\n",
			lon[i], lat[i], (ve[i])*su, (vn[i])*su, sqrt(vary[i][0][0])*su, sqrt(vary[i][1][1])*su, 
			vary[i][0][1]/sqrt(vary[i][0][0]*vary[i][1][1]));
	      }
	    sum1 = sum1 +  resy + resx;
	    if(resx<9)
	      sum = sum + resx;
	    else {
	      if(resy<9) {
		sum = sum + resy;
	      }
	      else {
		rig++;
	      }
	    }
	  }
	  else
	    rig++;
	  if(g_flag) {
	    if(fabs(vary[i][0][0])>0.0 && fabs(vary[i][1][1])>0.0)
	      sumvar = sumvar + (ve[i]*ve[i])/vary[i][0][0] + (vn[i]*vn[i])/vary[i][1][1];
	  }
	}
	printf("Total weighted sum of squared misfit: %13.4e\n", sum1);
	printf("The misfit per degree of freedom: %13.4e\n", sqrt(sum1/(2.0*(num))));
	printf("Total weighted sum of squared misfit excluding outflyers: %13.4e\n", sum);
	printf("The misfit per degree of freedom excluding outflyers: %13.4e\n", sqrt(sum/(2.0*(num-rig))));

	printf("The relative weighting factor: %13.4e\n", sumvar/(num1*2.0));
	printf("number of large misfit points =%6d, %9.3f percent of the total number\n", g1, g1*100/(num1*2.0));
	printf("number of larger misfit points =%6d, %9.3f percent of the total number\n", g2, g2*100/(num1*2.0));


return 0;
}

void read_a_line(FILE *f) {
	char c;
	FILE *f1;
	f1=f;
	c=fgetc(f1);
	while(c == '\n')
		c=fgetc(f1);
	while( (c = fgetc(f1)) != '\n' ) 
/*	putchar(c) */  ;
/*	putchar(c) */ ;
}


void deal_with_options(int ac, char **av, char* filename, char* filename1) {
	char *s, fname[2][25];
	int	argc, fnum=0;
	argc = ac;
	if( ac < 5 ) {
		usage();
		exit(1);
	}
	while (--argc > 0) {
		if((*(++av))[0]=='-') {
			for (s=av[0]+1; *s; s++)
				switch (*s) {
				case 'h':
					usage();
					exit(1);
					break;
				case 'm':
					argc--;
					sprintf((char *) fname[1], "%s", *(++av));
					break;
				case 'o':
					argc--;
					sprintf((char *) fname[0], "%s", *(++av));
					break;
				case 'g':
					g_flag=1;
					break;
				case 'd':
					d_flag=1;
					break;

				case 'c':
					argc--;
					if(!(sscanf(*(++av), "%lf", &sigma))) {
						printf("Error in command line input\n");
						usage();
						exit(1);
					}
					break;
				case 'e':
					argc--;
					if(!(sscanf(*(++av), "%d", &e_flag))) {
						printf("Error in command line input\n");
						usage();
						exit(1);
					}
					break;

				default:
					printf("Error in command line input\n");
					usage();
					exit(1);
					break;
				}

		}
	}
	strcpy(filename, fname[0]);
	strcpy(filename1, fname[1]);

}

void usage(void) {
printf("Usage: velocity_diff -o file1 -m file2 [-h] [-g] [-e 1/2] \n");
printf("\tfile1 is the velocity file name containing observed velocities\n");
printf("\tfile2 is the velocity file name containing model velocities\n");
printf("\tIt must have the same format as velocity.out\n");
printf("\tThe default velocityfile names are:\n");
printf("\tfile1=velocity_obsrved.out, file12=velocity_model.out\n");
printf("\tconfidence is the confidence level of the fit to be calculated\n");
printf("options:\n");
printf("	h	for instructions.\n");
printf("	g	for printing out mean sdv.\n");
printf("        e       specify which error to use in the differential vector. 1 - uses error in file1\n");
printf("                        2 - uses error in file 2\n");
printf("	d	use this flag to plot only velocity vectors which are not fitted within errors\n");
}
