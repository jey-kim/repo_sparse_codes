/* This program is used to preapre GPS.dat
   which is used in general_spline_fit_with_GPS
   from a GPS data file (should be named as GPS_raw.dat)
   with a format as follows:
   Longitude   Latitude    V_e      V_n     Sigma_e  Sigma_n  Site    C_en Ref_frame
   114.755     -3.447     -32.00  -64.00    9.00    3.00     -0.0500 site1  ITF94
	.
	.
	.

  Where the first line is the headings of the data format.
  The data starts from the second line.
   Any bugs found when using this program should be directed to
    Bingming Shen-Tu
    Geosciences, SUNY at Stony Brook  */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define radius 6.371
#define epsilon 0.005
#define NGPS 10000
#define NNODE 100
#define N 200

void read_a_line(FILE *f);
void create_latlong();
void deal_with_options(int ac, char **av, char* filename);
void usage(void);
int GPS_FORMAT = 1;
int main(int argc, char **argv) {
	int i, j, k, nx, ny, n, mm, ia[NGPS], num, inode[NGPS];
	int nfree, id[N][N], id0[N][N], jlat[N][N], ilong[N][N], ntotal;
	int im, m, aa, bb, iaa, current_num, nd, nnode, ndumy, ii, jj;
	char station[NGPS][25], command[200];
	char refname[NGPS][25], current_ref[15], filein[25];
	int refnum[NGPS];
	float ylat[N][N], xlong[N][N], dummy;
	float lon[NGPS], lat[NGPS], ve[NGPS], vn[NGPS];
	float sigx[NGPS], sigy[NGPS], cne[NGPS];
	float x[NGPS], y[NGPS];
	int inum[NGPS], kk, kkn;
	FILE *ipf, *gps, *fl, *ifg, *out1, *f2, *fg;

	strcpy(filein, "GPS_raw.dat");
	deal_with_options(argc, argv, filein);
	if( (ipf = fopen(filein, "r")) == NULL) {
	  printf("STOP: File %s not exits\n", filein);
	  exit(-1);
	}
	
	if( (ifg = fopen("geometry.dat", "r")) == NULL) {
	  printf("STOP: You must have a valid geometry.dat file in the current directory\n");
	  exit(1);
	}
	if( (fg = fopen("sparse.log", "r")) == NULL) {
	  printf("STOP: You must have a valid sparse.log in the current directory.\n");
	  exit(1);
	}
	fl = fopen("latlong_inpoints.dat", "w");
	f2 = fopen("gps_in.dat", "w");
	gps = fopen("GPS.dat", "w");
	out1 = fopen("scratch.dat", "w");

/*	read data from geometry.dat */
	fscanf(ifg, "%d%d%d", &nx, &ny, &nfree);

	for(j = 0; j <= ny; j++) {
	  for(i =0; i <= nx; i++) {
		fscanf(ifg, "%d%d%d%d%d", &ilong[j][i], &jlat[j][i], &id0[j][i],&im,&im);
		if(id0[j][i] != 0)
		  fscanf(ifg, "%f%f", &ylat[j][i], &xlong[j][i]);
		if(im % 2 == 0)
		  fscanf(ifg, "%f%f", &dummy, &dummy);
		if(im / 2 == 0)
		  fscanf(ifg, "%f%f", &dummy, &dummy);
		if(xlong[j][i] > 180.0)
		xlong[j][i] = xlong[j][i]-360.0;
	  }
	}

	fscanf(fg, "%d", &ntotal);
	for(k=0; k<ntotal; k++) {
	  fscanf(fg, "%d", &nd);
	  if(nd == 1) {
	    fscanf(fg, "%d%d", &i, &j);
	    fscanf(fg, "%d%d%d%d", &id[j][i], &ndumy, &ndumy, &ndumy);
	  }
	  else {
	    fscanf(fg, "%d%d%d%d", &nnode,  &ndumy, &ndumy, &ndumy);
	    for(jj=0; jj<ny; jj++) {
	      for(ii=0; ii<nx; ii++) {
		if(id0[jj][ii] == nd)
		  id[jj][ii] = nnode;
	      }
	    }
	  }
	}
	read_a_line(ipf);
	i = 0;

	if(GPS_FORMAT == 0) 
	{ /* old gps data format */
	  while ( (n = fscanf(ipf, "%s%f%f%f%f%f%f%f%s",
			      station[i], &lon[i], &lat[i], &ve[i], &vn[i],
			      &sigx[i], &sigy[i], &cne[i], refname[i])) >= 8)
	    {
	      if(sigx[i] <= 0.0 || sigy[i] <= 0.0 || cne[i]*cne[i] > 1.0) 
		{
		printf("Line #%d, error negative\n", i);
		exit(1);
		}
	      
	      if(lon[i]>180.0)
		lon[i] = lon[i] - 360.0;
	      /*printf("%8s %9.5f %9.5f %9.5f %9.5f %9.5f %9.5f %9.5f %s\n",station[i], lon[i], lat[i], ve[i], vn[i], 			                	sigx[i], sigy[i], cne[i],refname[i]); */ 
	      
	      if(i == 0 || ((strcmp(current_ref, refname[i]) != 0) &&
			    (strcmp("-", refname[i]) != 0) )) 
		{
		strcpy(current_ref, refname[i]);
		printf("Input the node no. for reference %s\n", current_ref);
		scanf("%d", &current_num);
		refnum[i] = current_num;
	      	}
	      else
		refnum[i] = current_num;
	        i++;
	    }
	}
	if(GPS_FORMAT == 1)
	  while ( (n = fscanf(ipf, "%f%f%f%f%f%f%f%s%s",
			      &lon[i], &lat[i], &ve[i], &vn[i],
			      &sigx[i], &sigy[i], &cne[i], station[i], refname[i])) >= 8)
	    {
	      
	      if(lon[i]>180.0)
		lon[i] = lon[i] - 360.0;
	      /*		printf("%8s %9.5f %9.5f %9.5f %9.5f %9.5f %9.5f %9.5f %s\n",
				station[i], lon[i], lat[i], ve[i], vn[i], sigx[i], sigy[i], cne[i],refname[i]); */ 
	      
	      if(i == 0 || ((strcmp(current_ref, refname[i]) != 0) &&
			    (strcmp("-", refname[i]) != 0) )) 
	      {
		strcpy(current_ref, refname[i]);
		printf("Input the node no. for reference %s\n", current_ref);
		scanf("%d", &current_num);
		refnum[i] = current_num;
	      }
	      else
		refnum[i] = current_num;
	      
	      i++;
	    }


	printf("The total number of GPS data is %6d\n\n", i);
	num = i;

	fprintf(out1, "%6d\n", num);
	for(i=0; i < num; i++)
	fprintf(out1, "%6d %9.5f %9.5f\n", i+1, lat[i], lon[i]);

	fclose(out1);
	sprintf(command, "make_sparse_geometry\n");
	system(command);
	sprintf(command, "convert_lat_long<<end\n 0 0 0\n3\nscratch.dat\nend\n");
/*	printf("%s\n", command); */
	system(command);

	sprintf(command, "cp lat_long.dat latlong_gps.dat\n");
	system(command);

	out1 = fopen("lat_long.dat", "r");
	fscanf(out1, "%d", &num);
	fprintf(gps, "%6d\n", num);
	kkn = 0;
	for( m = 0; m < num; m++) {
		fscanf(out1, "%d%f%f%d", &k, &x[m], &y[m], &inum[m]);
		kk = 0;  /* 94 */
		iaa = inum[m]-1;
		ve[iaa] = ve[iaa] / radius;
		vn[iaa] = vn[iaa] / radius;
		sigx[iaa] = sigx[iaa] / radius;
		sigy[iaa] = sigy[iaa] / radius;

		for(j =0; j <= ny; j++) {
			for(i=0; i <= nx; i++) {
			if(id[j][i] != 0) {
			  aa = fabs(ylat[j][i] - lat[iaa]) < epsilon;
			  bb = fabs(xlong[j][i] - lon[iaa]) < epsilon;
			  if(aa && bb) {
				kk++;
	/*fprintf(gps, "%6d %6d %6d %9.5f %9.5f\n", m+1, refnum[iaa], id[j][i], lat[iaa], lon[iaa]); */
				mm=-1*(m+1);
				fprintf(gps, "%6d %6d %6d %9.5f %9.5f\n",
				m+1, refnum[iaa], mm, lat[iaa], lon[iaa]);
				fprintf(gps, "%9.5f %9.5f\n", ve[iaa], vn[iaa]);
				fprintf(gps, "%9.5f %9.5f %9.5f\n", sigx[iaa],
					sigy[iaa], cne[iaa]);
			  }

			}}}

		if(kk < 1) {
		   kkn--;
		   mm=-1*(m+1);
	       	   fprintf(gps, "%6d %6d %6d %9.5f %9.5f\n",
			m+1, refnum[iaa], mm, lat[iaa], lon[iaa]);
	 	   fprintf(gps, "%9.5f %9.5f\n", ve[iaa], vn[iaa]);
		   fprintf(gps, "%9.5f %9.5f %9.5f\n", sigx[iaa], sigy[iaa],
					cne[iaa]);
	
		  fprintf(fl, "%6d %9.5f %9.5f\n", -kkn, lat[iaa], lon[iaa]);
		  fprintf(f2, "%10.5f %10.5f %10.5f %10.5f %10.5f %10.5f %10.5f %s  %s\n",
			lon[iaa]<0.0?360.0+lon[iaa]:lon[iaa], lat[iaa], ve[iaa]*radius, vn[iaa]*radius, sigx[iaa]*radius,
			sigy[iaa]*radius, cne[iaa], station[iaa], refname[iaa]);
		}

	}

	return 0;
}

void read_a_line(FILE *f) {
	char c;
	FILE *f1;
	f1=f;
	c=fgetc(f1);
	while( (c = fgetc(f1)) != '\n' ) 
/*	putchar(c) */;
	putchar(c);
}

void create_latlong() {}


void deal_with_options(int ac, char **av, char* filename) {
	char *s;
	int	argc, fnum=0;
	argc = ac;
/*	if(ac < 2) {
		usage();
		exit(1);}
	else
*/
	while (--argc > 0) {
		if((*(++av))[0]=='-') {
			for (s=av[0]+1; *s; s++)
				switch (*s) {
				case 'h':
					usage();
					exit(1);
					break;
				case 's':
				  GPS_FORMAT = 0;
					break;
				case 'n':
				  GPS_FORMAT = 2;
				case 'y':
					break;
				default:
					break;
				}
		}
		else {
			sprintf((char *) filename, "%s", *av);
			fnum+=1;
		}
	}

}

void usage(void) {
printf("Usage: prepare_gps_sparse datafile [-h] [-s] \n");
printf("\tdatafile is the file name containing the GPS data\n");
printf("\tIt must have the following format:\n");
printf("\tlong.\tlat.\tV_EW\tV_NS\tsed_EW\tsed_NS\tcof_EW_NS\tname of site\tRef_frame\n");
printf("The default datafile name is GPS_raw.dat\n");
printf("options:\n");
printf("	h	for instructions.\n");
printf("        s       switch for the old data format as follows:\n");
printf("\tname of site\tlong.\tlat.\tV_EW\tV_NS\tsed_EW\tsed_NS\tcof_EW_NS\tRef_frame\n");
}
