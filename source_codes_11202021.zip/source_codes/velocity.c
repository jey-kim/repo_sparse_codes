#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	<math.h>
#define		EARTH_RADIUS 6371.0	/* in km */
#define		MU 3.0e11		/* shear modulus in cgs */
#define		DEPTH 15.0		/* seismogenic thickness in km */
#define		MAX_POINTS 40000
#define		MAX_KNOTS 40000

double sunit=1.0e-9;
void read_a_line(FILE *f);
void deal_with_options(int ac, char **av, char* filename);
void usage(void);


int main(int argc, char **argv)
{
	double lat[MAX_KNOTS], lon[MAX_KNOTS], vary[MAX_KNOTS][3][3];
	double ve[MAX_KNOTS], vn[MAX_KNOTS], dm;
	double su, cof, vx, vy;
	FILE *inf, *outf;
	int i, j, k, num;
	char filein[25];
	char fileout[25];
	su = EARTH_RADIUS*1.0e6*sunit;
	strcpy(filein, "velocity.out");
	strcpy(fileout, "vel.gmt");
	if(argc == 2) {
	  printf("argc = 2, %s\n", argv[1]);
	  strcpy(filein, argv[1]);
	}
/*	deal_with_options(argc, argv, filein); */
	if( (inf = fopen(filein, "r")) == NULL) {
		printf(" file %s not exist\n", filein);
		exit(1);
	}
	outf = fopen(fileout, "w");

	read_a_line(inf);
	i=0;
	while( (k=fscanf(inf, "%d", &j)) == 1) {
		fscanf(inf , "%lf%lf%lf%lf%lf%lf%lf%lf", 
			&lat[i], &lon[i], &ve[i], &vn[i], &dm, &dm, &dm, &dm);
	/*	printf("%5d\n", j); */
		i++;
	}
	num = i;
	printf("Total number of points is %d\n", num);
	read_a_line(inf);
	for(i=0; i<num; i++) {
		read_a_line(inf);
		read_a_line(inf);
		for(j=0; j<3; j++){
			for(k=0; k<3; k++) {
				fscanf(inf, "%lf", &vary[i][j][k]);
				
			}
		}
	}

	for(i=0; i<num; i++) {
		if((vary[i][0][0]*vary[i][1][1])>0.0)
			cof = vary[i][0][1]/sqrt(vary[i][0][0]*vary[i][1][1]);
		else
			cof=0.0;
		vx = sqrt(vary[i][0][0]);
		vy = sqrt(vary[i][1][1]);
		if(lon[i] < 0.0)
			lon[i] = lon[i] + 360.0;
		fprintf(outf, "%10.3f %10.3f %10.3f %10.3f %10.3f %10.3f %8.4f\n",
			lon[i], lat[i], ve[i]*su, vn[i]*su, vx*su, vy*su, cof);
	}

}

void read_a_line(FILE *f) {
	char c;
	FILE *f1;
	f1=f;
	c=fgetc(f1);
	while(c == '\n')
		c=fgetc(f1);
	while( (c = fgetc(f1)) != '\n' ) 
/*	putchar(c) */  ;
/*	putchar(c) */ ;
}


void deal_with_options(int ac, char **av, char* filename) {
	char *s;
	int	argc, fnum=0;
	argc = ac;
/*	if(ac < 2) {
		usage();
		exit(1);}
	else
*/
	while (--argc > 0) {
		if((*(++av))[0]=='-') {
			for (s=av[0]+1; *s; s++)
				switch (*s) {
				case 'h':
					usage();
					exit(1);
					break;
				case 's':
					break;
				case 'y':
					break;
				default:
					break;
				}
		}
		else {
			sprintf((char *) filename, "%s", *av);
			fnum+=1;
		}
	}

}

void usage(void) {
printf("Usage: velocity datafile [-h] \n");
printf("\tdatafile is the file name containing the GPS data\n");
printf("\tIt must have the same format as velocity.out\n");
printf("\tThe default datafile name is velocity.out\n");
printf("options:\n");
printf("	h	for instructions.\n");
}
